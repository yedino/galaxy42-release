#!/bin/bash

echo "Ok I am in the namespace..."

while true ; do sleep 3600 || break ; done

echo "Done waiting in the namespace"

