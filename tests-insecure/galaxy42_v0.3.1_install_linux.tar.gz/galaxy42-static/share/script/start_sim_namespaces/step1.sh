sudo netpriv1 bash ./step2.sh "$1"
echo "Exited the namespaces (they are destroyed now probably?)"
