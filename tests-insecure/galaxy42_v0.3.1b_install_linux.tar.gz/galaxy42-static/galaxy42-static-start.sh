GCONV_PATH="staticlibs:$GCONV_PATH" ./tunserver.elf "$@"
