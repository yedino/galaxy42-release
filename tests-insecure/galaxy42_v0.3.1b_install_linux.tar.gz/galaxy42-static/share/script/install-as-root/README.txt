
As root, run the ./install script here;

It will enter the directories here, and run the install script that is in each of them.

