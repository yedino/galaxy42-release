#!/usr/bin/env bash

function fail() {
       echo -e "\nERROR (in $0): " "$@"
       exit 1
}
